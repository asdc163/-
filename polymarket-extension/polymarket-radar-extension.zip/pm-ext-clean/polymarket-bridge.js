"use strict";
var PolymarketBridge = (() => {
  // src/content/polymarket-bridge.ts
  function extractCredsFromObj(obj) {
    if (!obj || typeof obj !== "object") return null;
    const o = obj;
    const apiKey = o.apiKey ?? o.api_key ?? o.POLY_API_KEY;
    const secret = o.secret ?? o.POLY_SIGNATURE;
    const passphrase = o.passphrase ?? o.POLY_PASSPHRASE;
    const address = o.address ?? o.maker ?? o.POLY_ADDRESS;
    if (apiKey && secret && passphrase && address) {
      return { address: address.toLowerCase(), apiKey, secret, passphrase };
    }
    for (const field of ["credentials", "creds", "auth", "clob", "wallet", "user", "data", "api"]) {
      if (o[field]) {
        const nested = extractCredsFromObj(o[field]);
        if (nested) return nested;
      }
    }
    return null;
  }
  function scanLocalStorage() {
    try {
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (!key) continue;
        try {
          const raw = localStorage.getItem(key);
          if (!raw || raw[0] !== "{") continue;
          if (!raw.includes("secret") && !raw.includes("passphrase")) continue;
          const obj = JSON.parse(raw);
          const creds = extractCredsFromObj(obj);
          if (creds) return creds;
        } catch {
        }
      }
    } catch {
    }
    return null;
  }
  function runInMainWorld(code, nonce, timeoutMs = 5e3) {
    return new Promise((resolve, reject) => {
      const handler = (event) => {
        if (!event.data || event.data.__pmNonce !== nonce) return;
        window.removeEventListener("message", handler);
        clearTimeout(timer);
        if (event.data.error) reject(new Error(event.data.error));
        else resolve(event.data.result);
      };
      const timer = setTimeout(() => {
        window.removeEventListener("message", handler);
        reject(new Error("MAIN world call timed out"));
      }, timeoutMs);
      window.addEventListener("message", handler);
      const script = document.createElement("script");
      script.textContent = `(function(){const __n=${JSON.stringify(nonce)};${code}})();`;
      document.documentElement.appendChild(script);
      script.remove();
    });
  }
  async function checkEthProvider() {
    const nonce = `_pmchk_${Date.now()}`;
    try {
      return await runInMainWorld(
        `window.postMessage({__pmNonce:__n,result:typeof window.ethereum!=='undefined'},'*');`,
        nonce,
        2e3
      );
    } catch {
      return false;
    }
  }
  async function signOrderInPage(address, order, domain) {
    const nonce = `_pmsign_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
    const typedData = {
      domain,
      types: {
        Order: [
          { name: "salt", type: "uint256" },
          { name: "maker", type: "address" },
          { name: "signer", type: "address" },
          { name: "taker", type: "address" },
          { name: "tokenId", type: "uint256" },
          { name: "makerAmount", type: "uint256" },
          { name: "takerAmount", type: "uint256" },
          { name: "expiration", type: "uint256" },
          { name: "nonce", type: "uint256" },
          { name: "feeRateBps", type: "uint256" },
          { name: "side", type: "uint8" },
          { name: "signatureType", type: "uint8" }
        ]
      },
      primaryType: "Order",
      message: order
    };
    const tdJson = JSON.stringify(JSON.stringify(typedData));
    const addrJson = JSON.stringify(address);
    const code = `
    (async function(){
      try{
        if(!window.ethereum){
          window.postMessage({__pmNonce:__n,error:'NO_WALLET'},'*');
          return;
        }
        const sig=await window.ethereum.request({
          method:'eth_signTypedData_v4',
          params:[${addrJson},${tdJson}]
        });
        window.postMessage({__pmNonce:__n,result:sig},'*');
      }catch(e){
        window.postMessage({__pmNonce:__n,error:e.message||String(e)},'*');
      }
    })();
  `;
    return runInMainWorld(code, nonce, 12e4);
  }
  chrome.runtime.onMessage.addListener(
    (msg, _sender, sendResponse) => {
      if (msg.type === "PM_GET_SESSION") {
        const creds = scanLocalStorage();
        if (!creds) {
          sendResponse({ session: null });
          return true;
        }
        checkEthProvider().then((hasEthProvider) => {
          sendResponse({ session: { ...creds, hasEthProvider } });
        });
        return true;
      }
      if (msg.type === "PM_SIGN_ORDER") {
        const { address, order, domain } = msg;
        if (!address || !order || !domain) {
          sendResponse({ error: "Missing sign params" });
          return true;
        }
        signOrderInPage(address, order, domain).then((signature) => sendResponse({ signature })).catch((err) => sendResponse({ error: err.message }));
        return true;
      }
      return false;
    }
  );
})();
